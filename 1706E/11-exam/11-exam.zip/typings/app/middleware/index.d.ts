// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAuthority = require('../../../app/middleware/authority');

declare module 'egg' {
  interface IMiddleware {
    authority: typeof ExportAuthority;
  }
}
