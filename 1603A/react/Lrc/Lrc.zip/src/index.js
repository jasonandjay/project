import React from 'react';
import ReactDOM from 'react-dom';
import Music from './components/Music';

ReactDOM.render(<Music />, document.getElementById('root'));
